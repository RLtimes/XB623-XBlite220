/* ----------------------------------------------------------------------- *
 * G L S a m p l e 1 . h
 *
 * main header file for the GLSAMPLE1 application
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample1 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGLSample1App:
// See GLSample1.cpp for the implementation of this class
//

class CGLSample1App : public CWinApp
{
public:
	CGLSample1App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample1App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGLSample1App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
