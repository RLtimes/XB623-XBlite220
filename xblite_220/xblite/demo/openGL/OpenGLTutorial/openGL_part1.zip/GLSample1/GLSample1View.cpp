/* ----------------------------------------------------------------------- *
 * GLSample1View.cpp 
 *
 * implementation of the CGLSample1View class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample1 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample1.h"

#include "GLSample1Doc.h"
#include "GLSample1View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample1View

IMPLEMENT_DYNCREATE(CGLSample1View, CView)

BEGIN_MESSAGE_MAP(CGLSample1View, CView)
	//{{AFX_MSG_MAP(CGLSample1View)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample1View construction/destruction

CGLSample1View::CGLSample1View()
{
	m_hGLContext = NULL;
	m_GLPixelIndex = 0;
}

CGLSample1View::~CGLSample1View()
{
}

BOOL CGLSample1View::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= (WS_CLIPCHILDREN | WS_CLIPSIBLINGS);

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample1View drawing

void CGLSample1View::OnDraw(CDC* pDC)
{
	CGLSample1Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample1View diagnostics

#ifdef _DEBUG
void CGLSample1View::AssertValid() const
{
	CView::AssertValid();
}

void CGLSample1View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGLSample1Doc* CGLSample1View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLSample1Doc)));
	return (CGLSample1Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample1View message handlers

BOOL CGLSample1View::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR pixelDesc;

	pixelDesc.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pixelDesc.nVersion	= 1;

	pixelDesc.dwFlags	=	PFD_DRAW_TO_WINDOW | 
							PFD_DRAW_TO_BITMAP | 
							PFD_SUPPORT_OPENGL | 
							PFD_SUPPORT_GDI | 
							PFD_STEREO_DONTCARE;

	pixelDesc.iPixelType		= PFD_TYPE_RGBA;
	pixelDesc.cColorBits		= 32;
	pixelDesc.cRedBits			= 8;
	pixelDesc.cRedShift			= 16;
	pixelDesc.cGreenBits		= 8;
	pixelDesc.cGreenShift		= 8;
	pixelDesc.cBlueBits			= 8;
	pixelDesc.cBlueShift		= 0;
	pixelDesc.cAlphaBits		= 0;
	pixelDesc.cAlphaShift		= 0;
	pixelDesc.cAccumBits		= 64;	
	pixelDesc.cAccumRedBits		= 16;
	pixelDesc.cAccumGreenBits	= 16;
	pixelDesc.cAccumBlueBits	= 16;
	pixelDesc.cAccumAlphaBits	= 0;
	pixelDesc.cDepthBits		= 32;
	pixelDesc.cStencilBits		= 8;
	pixelDesc.cAuxBuffers		= 0;
	pixelDesc.iLayerType		= PFD_MAIN_PLANE;
	pixelDesc.bReserved			= 0;
	pixelDesc.dwLayerMask		= 0;
	pixelDesc.dwVisibleMask		= 0;
	pixelDesc.dwDamageMask		= 0;

	m_GLPixelIndex = ChoosePixelFormat(hDC, 
										&pixelDesc);
	if (m_GLPixelIndex==0)
	{
		m_GLPixelIndex = 1;	// Let's choose a default index.
		if (DescribePixelFormat( hDC, 
								 m_GLPixelIndex, 
								 sizeof(PIXELFORMATDESCRIPTOR), 
								 &pixelDesc)==0)
		{
			DWORD errorCode = GetLastError();
			CString errorStr;
			errorStr.Format("DescribePixelFormat returned error code %d.", errorCode);
			AfxMessageBox(errorStr);
			return FALSE;
		}
	}

	if (SetPixelFormat(	hDC, 
						m_GLPixelIndex, 
						&pixelDesc)==FALSE)
	{
		DWORD errorCode = GetLastError();
		CString errorStr;
		errorStr.Format("SetPixelFormat returned error code %d.", errorCode);
		AfxMessageBox(errorStr);
		return FALSE;
	}

	return TRUE;

}

int CGLSample1View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	HWND hWnd = GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);

	if (SetWindowPixelFormat(hDC)==FALSE)
		return 0;

	if (CreateViewGLContext(hDC)==FALSE)
		return 0;
	
	return 0;
}

BOOL CGLSample1View::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);
	if (m_hGLContext == NULL)
	{
		DWORD errorCode = GetLastError();
		CString errorStr;
		errorStr.Format("wglCreateContext returned error code %d.", errorCode);
		AfxMessageBox(errorStr);
		return FALSE;
	}

	if (wglMakeCurrent(hDC, m_hGLContext)==FALSE)
	{
		DWORD errorCode = GetLastError();
		CString errorStr;
		errorStr.Format("wglCreateContext returned error code %d.", errorCode);
		AfxMessageBox(errorStr);
		return FALSE;
	}

	return TRUE;
}

void CGLSample1View::OnDestroy() 
{
	if(wglGetCurrentContext()!=NULL) 
	{
		// make the rendering context not current
		wglMakeCurrent(NULL, NULL) ;
	}
	
	if (m_hGLContext!=NULL)
	{
		wglDeleteContext(m_hGLContext);
		m_hGLContext = NULL;
	}

	// Now the associated DC can be released.
	CView::OnDestroy();
}
