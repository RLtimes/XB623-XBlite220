/* ----------------------------------------------------------------------- *
 * s t d a f x . c p p 
 *
 * source file that includes just the standard includes
 * GLSample1.pch will be the pre-compiled header            
 * stdafx.obj will contain the pre-compiled type information
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample1 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */


#include "stdafx.h"

