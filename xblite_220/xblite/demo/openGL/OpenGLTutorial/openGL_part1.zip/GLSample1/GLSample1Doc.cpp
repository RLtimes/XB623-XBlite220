/* ----------------------------------------------------------------------- *
 * G L S a m p l e 1 D o c . c p p 
 *
 * implementation of the CGLSample1Doc class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample1 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample1.h"

#include "GLSample1Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample1Doc

IMPLEMENT_DYNCREATE(CGLSample1Doc, CDocument)

BEGIN_MESSAGE_MAP(CGLSample1Doc, CDocument)
	//{{AFX_MSG_MAP(CGLSample1Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample1Doc construction/destruction

CGLSample1Doc::CGLSample1Doc()
{
	// TODO: add one-time construction code here

}

CGLSample1Doc::~CGLSample1Doc()
{
}

BOOL CGLSample1Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample1Doc serialization

void CGLSample1Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample1Doc diagnostics

#ifdef _DEBUG
void CGLSample1Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGLSample1Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample1Doc commands
