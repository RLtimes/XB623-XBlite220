/* ----------------------------------------------------------------------- *
 * G L S a m p l e 4 . h
 *
 * main header file for the GLSAMPLE4 application
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample4 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGLSample4App:
// See GLSample4.cpp for the implementation of this class
//

class CGLSample4App : public CWinApp
{
public:
	CGLSample4App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample4App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGLSample4App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
