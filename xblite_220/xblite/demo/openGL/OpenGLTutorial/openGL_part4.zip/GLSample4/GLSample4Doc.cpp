/* ----------------------------------------------------------------------- *
 * G L S a m p l e 4 D o c . c p p
 *
 * implementation of the CGLSample4Doc class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample4 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample4.h"

#include "GLSample4Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample4Doc

IMPLEMENT_DYNCREATE(CGLSample4Doc, CDocument)

BEGIN_MESSAGE_MAP(CGLSample4Doc, CDocument)
	//{{AFX_MSG_MAP(CGLSample4Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample4Doc construction/destruction

CGLSample4Doc::CGLSample4Doc()
{
	// TODO: add one-time construction code here
	m_xRotate = 0;
	m_yRotate = 0;
}

CGLSample4Doc::~CGLSample4Doc()
{
}

BOOL CGLSample4Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample4Doc serialization

void CGLSample4Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample4Doc diagnostics

#ifdef _DEBUG
void CGLSample4Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGLSample4Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample4Doc commands

void CGLSample4Doc::RenderScene(void)
{
	GLfloat LightAmbient[] =  { 0.1f, 0.1f, 0.1f, 0.1f};
	GLfloat LightDiffuse[] =  { 0.7f, 0.7f, 0.7f, 0.7f};
	GLfloat LightSpecular[] = { 0.0f, 0.0f, 0.0f, 0.1f};
	GLfloat LightPosition[] = { 5.0f, 5.0f, 5.0f, 0.0f}; 

	GLfloat RedSurface[]   = { 1.0f, 0.0f, 0.0f, 1.0f};
	GLfloat GreenSurface[] = { 0.0f, 1.0f, 0.0f, 1.0f};
	GLfloat BlueSurface[]  = { 0.0f, 0.0f, 1.0f, 1.0f};

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
//	glClear(GL_COLOR_BUFFER_BIT);

	glLightfv(GL_LIGHT0, GL_AMBIENT, LightAmbient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, LightSpecular);
	glLightfv(GL_LIGHT0, GL_POSITION, LightPosition);
	glEnable(GL_LIGHT0);

	glPushMatrix();	
		glTranslated(0.0, 0.0, -8.0);
		glRotated(m_xRotate, 1.0, 0.0, 0.0);
		glRotated(m_yRotate, 0.0, 1.0, 0.0);

		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, RedSurface);
		glBegin(GL_POLYGON);
			glNormal3d(  1.0,  0.0,  0.0);
			glVertex3d(  1.0,  1.0,  1.0);
			glVertex3d(  1.0, -1.0,  1.0);
			glVertex3d(  1.0, -1.0, -1.0);
			glVertex3d(  1.0,  1.0, -1.0);
		glEnd();

		glBegin(GL_POLYGON);
			glNormal3d( -1.0,  0.0,  0.0);
			glVertex3d( -1.0, -1.0,  1.0);
			glVertex3d( -1.0,  1.0,  1.0);
			glVertex3d( -1.0,  1.0, -1.0);
			glVertex3d( -1.0, -1.0, -1.0);
		glEnd();

		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, GreenSurface);
		glBegin(GL_POLYGON);
			glNormal3d(  0.0,  1.0,  0.0);
			glVertex3d(  1.0,  1.0,  1.0);
			glVertex3d( -1.0,  1.0,  1.0);
			glVertex3d( -1.0,  1.0, -1.0);
			glVertex3d(  1.0,  1.0, -1.0);
		glEnd();				  

		glBegin(GL_POLYGON);
			glNormal3d(  0.0, -1.0,  0.0);
			glVertex3d( -1.0, -1.0,  1.0);
			glVertex3d(  1.0, -1.0,  1.0);
			glVertex3d(  1.0, -1.0, -1.0);
			glVertex3d( -1.0, -1.0, -1.0);
		glEnd();

		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, BlueSurface);
		glBegin(GL_POLYGON);
			glNormal3d(  0.0,  0.0,  1.0);
			glVertex3d(  1.0,  1.0,  1.0);
			glVertex3d( -1.0,  1.0,  1.0);
			glVertex3d( -1.0, -1.0,  1.0);
			glVertex3d(  1.0, -1.0,  1.0);
		glEnd();

		glBegin(GL_POLYGON);
			glNormal3d(  0.0,  0.0, -1.0);
			glVertex3d( -1.0,  1.0, -1.0);
			glVertex3d(  1.0,  1.0, -1.0);
			glVertex3d(  1.0, -1.0, -1.0);
			glVertex3d( -1.0, -1.0, -1.0);
		glEnd();
	glPopMatrix();

}
