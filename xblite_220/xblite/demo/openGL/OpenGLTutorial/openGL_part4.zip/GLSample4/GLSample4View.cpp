/* ----------------------------------------------------------------------- *
 * G L S a m p l e 4 V i e w . c p p
 *
 * implementation of the CGLSample4View class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample4 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample4.h"

#include "GLSample4Doc.h"
#include "GLSample4View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample4View

IMPLEMENT_DYNCREATE(CGLSample4View, CView)

BEGIN_MESSAGE_MAP(CGLSample4View, CView)
	//{{AFX_MSG_MAP(CGLSample4View)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample4View construction/destruction

CGLSample4View::CGLSample4View()
{
	m_hGLContext = NULL;
	m_GLPixelIndex = 0;
	m_LButtonDown = FALSE;
}

CGLSample4View::~CGLSample4View()
{
}

BOOL CGLSample4View::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= (WS_CLIPCHILDREN | WS_CLIPSIBLINGS);
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample4View drawing

void CGLSample4View::OnDraw(CDC* pDC)
{
	CGLSample4Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample4View diagnostics

#ifdef _DEBUG
void CGLSample4View::AssertValid() const
{
	CView::AssertValid();
}

void CGLSample4View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGLSample4Doc* CGLSample4View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLSample4Doc)));
	return (CGLSample4Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample4View message handlers

BOOL CGLSample4View::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR pixelDesc;

	pixelDesc.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pixelDesc.nVersion	= 1;

	pixelDesc.dwFlags	=	PFD_DRAW_TO_WINDOW | 
							PFD_SUPPORT_OPENGL | 
							PFD_DOUBLEBUFFER | 
							PFD_STEREO_DONTCARE;  

	pixelDesc.iPixelType		= PFD_TYPE_RGBA;
	pixelDesc.cColorBits		= 32;
	pixelDesc.cRedBits		= 8;
	pixelDesc.cRedShift		= 16;
	pixelDesc.cGreenBits		= 8;
	pixelDesc.cGreenShift		= 8;
	pixelDesc.cBlueBits		= 8;
	pixelDesc.cBlueShift		= 0;
	pixelDesc.cAlphaBits		= 0;
	pixelDesc.cAlphaShift		= 0;
	pixelDesc.cAccumBits		= 64;	
	pixelDesc.cAccumRedBits		= 16;
	pixelDesc.cAccumGreenBits	= 16;
	pixelDesc.cAccumBlueBits	= 16;
	pixelDesc.cAccumAlphaBits	= 0;
	pixelDesc.cDepthBits		= 32;
	pixelDesc.cStencilBits		= 8;
	pixelDesc.cAuxBuffers		= 0;
	pixelDesc.iLayerType		= PFD_MAIN_PLANE;
	pixelDesc.bReserved		= 0;
	pixelDesc.dwLayerMask		= 0;
	pixelDesc.dwVisibleMask		= 0;
	pixelDesc.dwDamageMask		= 0;

	m_GLPixelIndex = ChoosePixelFormat( hDC, &pixelDesc);
	if (m_GLPixelIndex==0) // Let's choose a default index.
	{
		m_GLPixelIndex = 1;	
		if (DescribePixelFormat(hDC, 
						m_GLPixelIndex, 
						sizeof(PIXELFORMATDESCRIPTOR), 
						&pixelDesc)==0)
		{
			return FALSE;
		}
	}

	if (SetPixelFormat( hDC, 
				  m_GLPixelIndex, 
				  &pixelDesc)==FALSE)
	{
		return FALSE;
	}

	return TRUE;

}

int CGLSample4View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	HWND hWnd = GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);

	if (SetWindowPixelFormat(hDC)==FALSE)
		return 0;
	
	if (CreateViewGLContext(hDC)==FALSE)
		return 0;
	
	return 0;
}

BOOL CGLSample4View::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);
	if (m_hGLContext == NULL)
	{
		return FALSE;
	}

	if (wglMakeCurrent(hDC, m_hGLContext)==FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

void CGLSample4View::OnDestroy() 
{
	if(wglGetCurrentContext()!=NULL) 
	{
		// make the rendering context not current
		wglMakeCurrent(NULL, NULL) ;
	}
	
	if (m_hGLContext!=NULL)
	{
		wglDeleteContext(m_hGLContext);
		m_hGLContext = NULL;
	}

	// Now the associated DC can be released.
	CView::OnDestroy();
}

void CGLSample4View::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	GLsizei width, height;
	GLdouble aspect;

	width = cx;
	height = cy;

	if (cy==0)
		aspect = (GLdouble)width;
	else
		aspect = (GLdouble)width/(GLdouble)height;

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45, aspect, 1.0, 10.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glDrawBuffer(GL_BACK);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
}

void CGLSample4View::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
		
	CGLSample4Doc* pDoc = GetDocument();
	pDoc->RenderScene();

	
	SwapBuffers(dc.m_ps.hdc);
	// Do not call CView::OnPaint() for painting messages
}

void CGLSample4View::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_LButtonDown = TRUE;
	m_LDownPos = point;
	CView::OnLButtonDown(nFlags, point);
}

void CGLSample4View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_LButtonDown = FALSE;	
	CView::OnLButtonUp(nFlags, point);
}

void CGLSample4View::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (m_LButtonDown)
	{
		CGLSample4Doc* pDoc = GetDocument();
		CSize rotate = m_LDownPos - point;
		m_LDownPos = point;
		pDoc->m_yRotate -= rotate.cx/2;
		pDoc->m_xRotate -= rotate.cy/2;
		InvalidateRect(NULL, FALSE);
	}
	
	CView::OnMouseMove(nFlags, point);
}
