/* ----------------------------------------------------------------------- *
 * G L S a m p l e 3 D o c . c p p
 *
 * implementation of the CGLSample3Doc class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample3 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample3.h"

#include "GLSample3Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample3Doc

IMPLEMENT_DYNCREATE(CGLSample3Doc, CDocument)

BEGIN_MESSAGE_MAP(CGLSample3Doc, CDocument)
	//{{AFX_MSG_MAP(CGLSample3Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample3Doc construction/destruction

CGLSample3Doc::CGLSample3Doc()
{
	m_transY = 100;// the y offset of the arm								
	m_transX = 100;// the x offset of the arm
	m_angle2 = 15;	// the angle of the second part of the arm with respect to the first part
	m_angle1 = 15;	// the angle of the first part of the arm
}

CGLSample3Doc::~CGLSample3Doc()
{
}

BOOL CGLSample3Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	glNewList(ArmPart, GL_COMPILE);
		glBegin(GL_POLYGON);
			glVertex2f(-10.0f,  10.0f);
			glVertex2f(-10.0f, -10.0f);
			glVertex2f(100.0f, -10.0f);
			glVertex2f(100.0f,  10.0f);
		glEnd();
	glEndList();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample3Doc serialization

void CGLSample3Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample3Doc diagnostics

#ifdef _DEBUG
void CGLSample3Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGLSample3Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample3Doc commands

void CGLSample3Doc::RenderScene(void)
{
	glClear(GL_COLOR_BUFFER_BIT);

	glPushMatrix();
		glTranslated( m_transX, m_transY, 0);
		glRotated( m_angle1, 0, 0, 1);
		glPushMatrix();
			glTranslated( 90, 0, 0);
			glRotated( m_angle2, 0, 0, 1);
			glColor4f(0.0f, 1.0f, 0.0f, 1.0f);
			glCallList(ArmPart);
		glPopMatrix();
		glColor4f(1.0f, 0.0f, 0.0f, 1.0f);
		glCallList(ArmPart);
	glPopMatrix();

	glFlush();
}
