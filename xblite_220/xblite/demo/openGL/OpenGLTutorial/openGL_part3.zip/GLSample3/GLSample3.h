/* ----------------------------------------------------------------------- *
 * G L S a m p l e 3 . h 
 *
 * main header file for the GLSAMPLE3 application
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample3 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGLSample3App:
// See GLSample3.cpp for the implementation of this class
//

class CGLSample3App : public CWinApp
{
public:
	CGLSample3App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample3App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGLSample3App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
