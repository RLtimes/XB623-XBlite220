/* ----------------------------------------------------------------------- *
 * G L S a m p l e 3 D o c . h
 *
 * interface of the CGLSample3Doc class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample3 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

class CGLSample3Doc : public CDocument
{
protected: // create from serialization only
	CGLSample3Doc();
	DECLARE_DYNCREATE(CGLSample3Doc)

// Attributes
public:
	enum GLDisplayListNames
	{
		ArmPart=1
	};
	
	double m_transY;	// the y offset of the arm								
	double m_transX;	// the x offset of the arm
	double m_angle2;	// the angle of the second part of the arm with respect to the first part
	double m_angle1;	// the angle of the first part of the arm
	void RenderScene(void);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample3Doc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGLSample3Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGLSample3Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
