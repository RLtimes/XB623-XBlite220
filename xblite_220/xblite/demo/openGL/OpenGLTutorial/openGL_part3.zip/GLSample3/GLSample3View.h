/* ----------------------------------------------------------------------- *
 * G L S a m p l e 3 V i e w . h
 *
 * interface of the CGLSample3View class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample3 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

class CGLSample3View : public CView
{
protected: // create from serialization only
	CPoint m_RightDownPos;
	CPoint m_LeftDownPos;
	BOOL m_RightButtonDown;
	BOOL m_LeftButtonDown;
	HGLRC m_hGLContext;
	BOOL CreateViewGLContext(HDC hDC);
	int m_GLPixelIndex;
	BOOL SetWindowPixelFormat(HDC hDC);
	CGLSample3View();
	DECLARE_DYNCREATE(CGLSample3View)

// Attributes
public:
	CGLSample3Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample3View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGLSample3View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGLSample3View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLSample3View.cpp
inline CGLSample3Doc* CGLSample3View::GetDocument()
   { return (CGLSample3Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
